var index=0;
        function showgallerybox()
        {
        var h,w;
           
           h= screen.availHeight;
           w= screen.width;
        
           var xpos;
           xpos= (w/2)-350;
          
           
           document.getElementById("gallerybox").style.display="block";
           document.getElementById("gallerybox").style.left= (xpos+"px");
	   document.getElementById("gallerybox").style.top="30px";
	   document.getElementById("messagebox").style.zIndex="1";
	   document.getElementById("filemanagerintbox").style.zIndex="1";
	   document.getElementById("contactbox").style.zIndex="1";  
	   document.getElementById("musicbox").style.zIndex="1";
	   document.getElementById("filemanagerextbox").style.zIndex="1";
	   document.getElementById("videobox").style.zIndex="1"; 
	   document.getElementById("applicationbox").style.zIndex="1";
           document.getElementById("gallerybox").style.zIndex="99999";                
           scroll(0,0);
	  index=0;
	   viewGallery();	

              
        }
      
        function hidegallerybox()
        { 
	   gallerydm.removeEventListener('dragstart',drag_start5,false);
	   document.body.removeEventListener('dragover',drag_over5,false);
	   document.body.removeEventListener('drop',drop5,false); 
           document.getElementById("gallerybox").style.display="none";
              
        }



	 function getXMLObject()  //XML OBJECT
    {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();
    
        
    function viewGallery()
    {
	
document.getElementById("innergallerybox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";
        xmlhttp.open("GET","./getImages?index="+index,true);
        xmlhttp.onreadystatechange = twoGallery;
        //xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xmlhttp.send();
    }


	function previousgallery()
	{ 
	document.getElementById("innergallerybox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";
	index=index-20;
 	if(index<=0)
	  index=0;
	viewGallery();
	 

	}

	function nextgallery()
	{
	document.getElementById("innergallerybox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";

	index=index+20;
	viewGallery();
	

	}

function viewImage(imgpath)
{
	
document.getElementById("innergallerybox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";
        xmlhttp.open("GET","./viewImage?name="+imgpath,true);
        xmlhttp.onreadystatechange = twoGallery;
        xmlhttp.send();  
}
    
    
    function twoGallery()
    {
        if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 200)
            {   
                
                document.getElementById("innergallerybox").innerHTML=xmlhttp.responseText;//Update the HTML Form element
                
                }
        
      
              
            else
            {
                alert("Error during AJAX call. Please try again");
            }
        }
    }


     
        
