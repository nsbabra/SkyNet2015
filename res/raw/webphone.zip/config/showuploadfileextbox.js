
        function showuploadfileextbox()
        {
        var h,w;
           
           h= screen.availHeight;
           w= screen.width;
        
           var xpos;
           xpos= (w/2)-480;
          
           document.getElementById("createfolderextbox").style.display="none";
           document.getElementById("uploadfileextbox").style.display="block";
           document.getElementById("uploadfileextbox").style.left= (xpos+"px");
	   
	   document.getElementById("innerfilemanagerextbox").style.marginTop="200px";
	   document.getElementById("filemanagerextbox").style.height="600px";
	   document.getElementById("uploadfileextbox").style.zIndex="3";                   
           scroll(0,0);
     
           document.getElementById('uploadfolderip').value=location.hostname;
	  
        }


        function closeuploadfileextbox()
        {	
	  //document.getElementById("foldernameext").value="";
          document.getElementById("uploadfileextbox").style.display="none";
	  document.getElementById("innerfilemanagerextbox").style.marginTop="100px";
	  document.getElementById("filemanagerextbox").style.height="500px";
              
        }

    

