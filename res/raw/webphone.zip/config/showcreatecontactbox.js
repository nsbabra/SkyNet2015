
        function showcreatecontactbox()
        { 
        var h,w;
           
           h= screen.availHeight;
           w= screen.width;
        
           var xpos;
           xpos= (w/2)-480;
          
           
           document.getElementById("createcontactbox").style.display="block";
           document.getElementById("createcontactbox").style.left= (xpos+"px");
	   document.getElementById("innercontactbox").style.marginTop="180px";
	   document.getElementById("contactbox").style.height="580px";
	   document.getElementById("createcontactbox").style.zIndex="3";                   
           scroll(0,0);
	   
	  

              
        }

	
      
        function hidecreatecontactbox()
        {	addContacts();
	   document.getElementById("contactname").value="";
	   document.getElementById("contactnumber").value="";
           document.getElementById("createcontactbox").style.display="none";
	   document.getElementById("innercontactbox").style.marginTop="100px";
	   document.getElementById("contactbox").style.height="500px";
              
        }

	function closecreatecontactbox()
        {	
	   document.getElementById("contactname").value="";
	   document.getElementById("contactnumber").value="";
           document.getElementById("createcontactbox").style.display="none";
	   document.getElementById("innercontactbox").style.marginTop="100px";
	   document.getElementById("contactbox").style.height="500px";
              
        }

	function isNumberKey(evt)
     	 {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      	}

	
   function getXMLObject()  //XML OBJECT
    {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();
    
        
    function addContacts()
    {	
	var name, number;
	
	name= document.getElementById('contactname').value;
	number= document.getElementById('contactnumber').value;
	
        xmlhttp.open("GET","./createContact?name="+name+"&number="+number,true);
        xmlhttp.onreadystatechange = twoaddContacts;
        xmlhttp.send();
	
    }
    
    
    function twoaddContacts()
    {
        if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 204)
            {   
                
              viewContacts();
                
             }
             
            else
            {
                alert("Error during AJAX call. Please try again");
            }
        }
    }
     
    

