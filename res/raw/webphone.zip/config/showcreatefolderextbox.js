
        function showcreatefolderextbox()
        { 
        var h,w;
           
           h= screen.availHeight;
           w= screen.width;
        
           var xpos;
           xpos= (w/2)-480;
          
           document.getElementById("uploadfileextbox").style.display="none";
           document.getElementById("createfolderextbox").style.display="block";
           document.getElementById("createfolderextbox").style.left= (xpos+"px");
	   document.getElementById("innerfilemanagerextbox").style.marginTop="180px";
	   document.getElementById("filemanagerextbox").style.height="580px";
	   document.getElementById("createfolderextbox").style.zIndex="3";                   
           scroll(0,0);
	   
	  

              
        }

	
      
        function hidecreatefolderextbox()
        {	addFoldersext();
	  document.getElementById("foldernameext").value="";
          document.getElementById("createfolderextbox").style.display="none";
	  document.getElementById("innerfilemanagerextbox").style.marginTop="100px";
	  document.getElementById("filemanagerextbox").style.height="500px";
              
          setPath(currentpathext);
        }

	
        function closecreatefolderextbox()
        {	
	  document.getElementById("foldernameext").value="";
          document.getElementById("createfolderextbox").style.display="none";
	  document.getElementById("innerfilemanagerextbox").style.marginTop="100px";
	  document.getElementById("filemanagerextbox").style.height="500px";
              
        }

	
   function getXMLObject()  //XML OBJECT
    {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();
    
        
    function addFoldersext()
    {	
	var name;
	
	name= document.getElementById('foldernameext').value;
        xmlhttp.open("GET","./createFolder?name="+currentpathext+name,true);
        xmlhttp.onreadystatechange = twoaddFolders;
        xmlhttp.send();
		
    }
    
function twoaddFolders()
{	
	if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 204)
            {                   
                 viewFileManagerext(currentpathext);       
            }
           else if(xmlhttp.status == 200)
            {
                alert("Folder not added..!!");
		viewFileManagerext(currentpathext); 
	    }
	    else
	    {
		alert("Error during AJAX call. Please try again");
            }
        }
}

     
    

