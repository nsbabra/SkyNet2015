
        function showvideobox()
        {
        var h,w;
           
           h= screen.availHeight;
           w= screen.width;
        
           var xpos;
           xpos= (w/2)-350;
          
           
           document.getElementById("videobox").style.display="block";
           document.getElementById("videobox").style.left= (xpos+"px");
	   document.getElementById("videobox").style.top= "30px";
	   document.getElementById("messagebox").style.zIndex="1";
	   document.getElementById("filemanagerintbox").style.zIndex="1";
	   document.getElementById("contactbox").style.zIndex="1";  
	   document.getElementById("musicbox").style.zIndex="1";
	   document.getElementById("filemanagerextbox").style.zIndex="1";
	   document.getElementById("gallerybox").style.zIndex="1"; 
	   document.getElementById("applicationbox").style.zIndex="1";
	   document.getElementById("videobox").style.zIndex="99999";                  
           scroll(0,0);
	   
	  viewVideo();

              
        }
      
        function hidevideobox()
        {
	   videodm.removeEventListener('dragstart',drag_start3,false);
	   document.body.removeEventListener('dragover',drag_over3,false);
	   document.body.removeEventListener('drop',drop3,false);
           document.getElementById("videobox").style.display="none";
              
        }



   function getXMLObject()  //XML OBJECT
    {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();
    
        
    function viewVideo()
    {
	
document.getElementById("innervideobox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";
        xmlhttp.open("GET","./getVideo",true);
        xmlhttp.onreadystatechange = twoVideo;
        //xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xmlhttp.send();
    }
    
    
    function twoVideo()
    {
        if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 200)
            {   
                
                document.getElementById("innervideobox").innerHTML=xmlhttp.responseText;   //Update the HTML Form element
                
                }
        
      
              
            else
            {
                alert("Error during AJAX call. Please try again");
            }
        }
        }
     
        