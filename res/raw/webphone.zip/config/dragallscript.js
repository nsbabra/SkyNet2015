function drag_start(event) {

    var style = window.getComputedStyle(event.target, null);
    event.dataTransfer.setData("text/plain",
    (parseInt(style.getPropertyValue("left"),10)- event.clientX) + ',' + (parseInt(style.getPropertyValue("top"),10)- event.clientY));
}
function drag_over(event) {

    event.preventDefault();
    return false;
}
function drop(event) {

    var offset = event.dataTransfer.getData("text/plain").split(',');
    messagedm.style.left = (event.clientX + parseInt(offset[0],10)) + 'px';
    messagedm.style.top = (event.clientY + parseInt(offset[1],10)) + 'px';
    event.preventDefault();
    return false;
}
var messagedm = document.getElementById('messagebox');
function registermessage()
{

messagedm.style.zIndex="9999";
contactdm.style.zIndex="1";
applicationdm.style.zIndex="1";
videodm.style.zIndex="1";
musicdm.style.zIndex="1";
gallerydm.style.zIndex="1";
fileintdm.style.zIndex="1";
fileextdm.style.zIndex="1";
messagedm.addEventListener('dragstart',drag_start,false);
document.body.addEventListener('dragover',drag_over,false);
document.body.addEventListener('drop',drop,false); 
}

function unregistermessage()
{

messagedm.removeEventListener('dragstart',drag_start,false);
document.body.removeEventListener('dragover',drag_over,false);
document.body.removeEventListener('drop',drop,false); 
}





function drag_start1(event1) {
	
    var style1 = window.getComputedStyle(event1.target, null);
    event1.dataTransfer.setData("text/plain",
    (parseInt(style1.getPropertyValue("left"),10)- event1.clientX) + ',' + (parseInt(style1.getPropertyValue("top"),10)- event1.clientY));
}

function drag_over1(event1) {

    event1.preventDefault();
    return false;
}

function drop1(event1) {

    var offset = event1.dataTransfer.getData("text/plain").split(',');
    contactdm.style.left = (event1.clientX + parseInt(offset[0],10)) + 'px';
    contactdm.style.top = (event1.clientY + parseInt(offset[1],10)) + 'px';
    event1.preventDefault();
    return false;
}
var contactdm = document.getElementById('contactbox');
function registercontact()
{

contactdm.style.zIndex="9999";
messagedm.style.zIndex="1";
applicationdm.style.zIndex="1";
videodm.style.zIndex="1";
musicdm.style.zIndex="1";
gallerydm.style.zIndex="1";
fileintdm.style.zIndex="1";
fileextdm.style.zIndex="1";
contactdm.addEventListener('dragstart',drag_start1,false);
document.body.addEventListener('dragover',drag_over1,false);
document.body.addEventListener('drop',drop1,false); 
}
function unregistercontact()
{

contactdm.removeEventListener('dragstart',drag_start1,false);
document.body.removeEventListener('dragover',drag_over1,false);
document.body.removeEventListener('drop',drop1,false); 
}






function drag_start2(event2) {
	
    var style2 = window.getComputedStyle(event2.target, null);
    event2.dataTransfer.setData("text/plain",
    (parseInt(style2.getPropertyValue("left"),10)- event2.clientX) + ',' + (parseInt(style2.getPropertyValue("top"),10)- event2.clientY));
}

function drag_over2(event2) {

    event2.preventDefault();
    return false;
}

function drop2(event2) {

    var offset = event2.dataTransfer.getData("text/plain").split(',');
    applicationdm.style.left = (event2.clientX + parseInt(offset[0],10)) + 'px';
    applicationdm.style.top = (event2.clientY + parseInt(offset[1],10)) + 'px';
    event2.preventDefault();
    return false;
}
var applicationdm = document.getElementById('applicationbox');
function registerapplication()
{

applicationdm.style.zIndex="9999";
messagedm.style.zIndex="1";
contactdm.style.zIndex="1";
videodm.style.zIndex="1";
musicdm.style.zIndex="1";
gallerydm.style.zIndex="1";
fileintdm.style.zIndex="1";
fileextdm.style.zIndex="1";
applicationdm.addEventListener('dragstart',drag_start2,false);
document.body.addEventListener('dragover',drag_over2,false);
document.body.addEventListener('drop',drop2,false); 
}
function unregisterapplication()
{

applicationdm.removeEventListener('dragstart',drag_start2,false);
document.body.removeEventListener('dragover',drag_over2,false);
document.body.removeEventListener('drop',drop2,false); 
}



function drag_start3(event3) {
	
    var style3 = window.getComputedStyle(event3.target, null);
    event3.dataTransfer.setData("text/plain",
    (parseInt(style3.getPropertyValue("left"),10)- event3.clientX) + ',' + (parseInt(style3.getPropertyValue("top"),10)- event3.clientY));
}

function drag_over3(event3) {

    event3.preventDefault();
    return false;
}

function drop3(event3) {

    var offset = event3.dataTransfer.getData("text/plain").split(',');
    //var contactdm = document.getElementById('contactbox');
    videodm.style.left = (event3.clientX + parseInt(offset[0],10)) + 'px';
    videodm.style.top = (event3.clientY + parseInt(offset[1],10)) + 'px';
    event3.preventDefault();
    return false;
}
var videodm = document.getElementById('videobox');
function registervideo()
{

videodm.style.zIndex="9999";
messagedm.style.zIndex="1";
applicationdm.style.zIndex="1";
contactdm.style.zIndex="1";
musicdm.style.zIndex="1";
gallerydm.style.zIndex="1";
fileintdm.style.zIndex="1";
fileextdm.style.zIndex="1";
videodm.addEventListener('dragstart',drag_start3,false);
document.body.addEventListener('dragover',drag_over3,false);
document.body.addEventListener('drop',drop3,false); 
}
function unregistervideo()
{

videodm.removeEventListener('dragstart',drag_start3,false);
document.body.removeEventListener('dragover',drag_over3,false);
document.body.removeEventListener('drop',drop3,false); 
}




function drag_start4(event4) {
	
    var style4 = window.getComputedStyle(event4.target, null);
    event4.dataTransfer.setData("text/plain",
    (parseInt(style4.getPropertyValue("left"),10)- event4.clientX) + ',' + (parseInt(style4.getPropertyValue("top"),10)- event4.clientY));
}

function drag_over4(event4) {

    event4.preventDefault();
    return false;
}

function drop4(event4) {

    var offset = event4.dataTransfer.getData("text/plain").split(',');
    //var contactdm = document.getElementById('contactbox');
    musicdm.style.left = (event4.clientX + parseInt(offset[0],10)) + 'px';
    musicdm.style.top = (event4.clientY + parseInt(offset[1],10)) + 'px';
    event4.preventDefault();
    return false;
}
var musicdm = document.getElementById('musicbox');
function registermusic()
{

musicdm.style.zIndex="9999";
messagedm.style.zIndex="1";
applicationdm.style.zIndex="1";
videodm.style.zIndex="1";
contactdm.style.zIndex="1";
gallerydm.style.zIndex="1";
fileintdm.style.zIndex="1";
fileextdm.style.zIndex="1";
musicdm.addEventListener('dragstart',drag_start4,false);
document.body.addEventListener('dragover',drag_over4,false);
document.body.addEventListener('drop',drop4,false); 
}
function unregistermusic()
{

musicdm.removeEventListener('dragstart',drag_start4,false);
document.body.removeEventListener('dragover',drag_over4,false);
document.body.removeEventListener('drop',drop4,false); 
}


function drag_start5(event5) {
	
    var style5 = window.getComputedStyle(event5.target, null);
    event5.dataTransfer.setData("text/plain",
    (parseInt(style5.getPropertyValue("left"),10)- event5.clientX) + ',' + (parseInt(style5.getPropertyValue("top"),10)- event5.clientY));
}

function drag_over5(event5) {

    event5.preventDefault();
    return false;
}

function drop5(event5) {

    var offset = event5.dataTransfer.getData("text/plain").split(',');
    gallerydm.style.left = (event5.clientX + parseInt(offset[0],10)) + 'px';
    gallerydm.style.top = (event5.clientY + parseInt(offset[1],10)) + 'px';
    event5.preventDefault();
    return false;
}
var gallerydm = document.getElementById('gallerybox');
function registergallery()
{
gallerydm.style.zIndex="9999";
messagedm.style.zIndex="1";
applicationdm.style.zIndex="1";
videodm.style.zIndex="1";
musicdm.style.zIndex="1";
contactdm.style.zIndex="1";
fileintdm.style.zIndex="1";
fileextdm.style.zIndex="1";
gallerydm.addEventListener('dragstart',drag_start5,false);
document.body.addEventListener('dragover',drag_over5,false);
document.body.addEventListener('drop',drop5,false); 
}
function unregistergallery()
{

gallerydm.removeEventListener('dragstart',drag_start5,false);
document.body.removeEventListener('dragover',drag_over5,false);
document.body.removeEventListener('drop',drop5,false); 
}



function drag_start6(event6) {
	
    var style6 = window.getComputedStyle(event6.target, null);
    event6.dataTransfer.setData("text/plain",
    (parseInt(style6.getPropertyValue("left"),10)- event6.clientX) + ',' + (parseInt(style6.getPropertyValue("top"),10)- event6.clientY));
}

function drag_over6(event6) {

    event6.preventDefault();
    return false;
}

function drop6(event6) {

    var offset = event6.dataTransfer.getData("text/plain").split(',');
    //var contactdm = document.getElementById('contactbox');
    fileintdm.style.left = (event6.clientX + parseInt(offset[0],10)) + 'px';
    fileintdm.style.top = (event6.clientY + parseInt(offset[1],10)) + 'px';
    event6.preventDefault();
    return false;
}
var fileintdm = document.getElementById('filemanagerintbox');
function registerfileint()
{

fileintdm.style.zIndex="9999";
messagedm.style.zIndex="1";
applicationdm.style.zIndex="1";
videodm.style.zIndex="1";
musicdm.style.zIndex="1";
gallerydm.style.zIndex="1";
contactdm.style.zIndex="1";
fileextdm.style.zIndex="1";
fileintdm.addEventListener('dragstart',drag_start6,false);
document.body.addEventListener('dragover',drag_over6,false);
document.body.addEventListener('drop',drop6,false); 
}
function unregisterfileint()
{
fileintdm.removeEventListener('dragstart',drag_start6,false);
document.body.removeEventListener('dragover',drag_over6,false);
document.body.removeEventListener('drop',drop6,false); 
}


function drag_start7(event7) {
	
    var style7 = window.getComputedStyle(event7.target, null);
    event7.dataTransfer.setData("text/plain",
    (parseInt(style7.getPropertyValue("left"),10)- event7.clientX) + ',' + (parseInt(style7.getPropertyValue("top"),10)- event7.clientY));
}

function drag_over7(event7) {

    event7.preventDefault();
    return false;
}

function drop7(event7) {

    var offset = event7.dataTransfer.getData("text/plain").split(',');
    fileextdm.style.left = (event7.clientX + parseInt(offset[0],10)) + 'px';
    fileextdm.style.top = (event7.clientY + parseInt(offset[1],10)) + 'px';
    event7.preventDefault();
    return false;
}
var fileextdm = document.getElementById('filemanagerextbox');
function registerfileext()
{

fileextdm.style.zIndex="9999";
messagedm.style.zIndex="1";
applicationdm.style.zIndex="1";
videodm.style.zIndex="1";
musicdm.style.zIndex="1";
gallerydm.style.zIndex="1";
contactdm.style.zIndex="1";
fileintdm.style.zIndex="1";
fileextdm.addEventListener('dragstart',drag_start7,false);
document.body.addEventListener('dragover',drag_over7,false);
document.body.addEventListener('drop',drop7,false); 
}
function unregisterfileext()
{
fileextdm.removeEventListener('dragstart',drag_start7,false);
document.body.removeEventListener('dragover',drag_over7,false);
document.body.removeEventListener('drop',drop7,false); 
}