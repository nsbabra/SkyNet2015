
        function showsendmessagebox()
        { 
	
        var h,w;
           
           h= screen.availHeight;
           w= screen.width;
        
           var xpos;
           xpos= (w/2)-690;
          
           
           document.getElementById("sendmessagebox").style.display="block";
           document.getElementById("sendmessagebox").style.left= (xpos+"px");
	   document.getElementById("sendmessagebox").style.height= "408px";
	   document.getElementById("sendmessagebox").style.width= "715px";
	   document.getElementById("sendmessagebox").style.zIndex="3";                   
           scroll(0,0);
	   
	  

              
        }

	
      
        function hidesendmessagebox()
        {  sendMessage();	
	   document.getElementById("messagename").value="";
	   document.getElementById("messagetext").value="";
           document.getElementById("sendmessagebox").style.display="none";
	   
              
        }


 	function closesendmessagebox()
        {  	
	   document.getElementById("messagename").value="";
	   document.getElementById("messagetext").value="";
           document.getElementById("sendmessagebox").style.display="none";
	        
        }

	function isNumberKey(evt)
     	 {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      	}

	

	
   function getXMLObject()  //XML OBJECT
    {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();
    
        
    function sendMessage()
    {	
	var number, message;
	
	number= document.getElementById('messagename').value;
	message= document.getElementById('messagetext').value.replace(/\n/g,"%0D%0A");
	
        xmlhttp.open("GET","./sendMessage?number="+number+"&message="+message,true);
        xmlhttp.onreadystatechange = twosendMessage;
        xmlhttp.send();
	
    }
    
    
    function twosendMessage()
    {
        if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 204)
            {   
                
               alert("Message has been sent..!!");
                
            }
        
      
              
            else
            {
                alert("Error during AJAX call. Please try again");
            }
        }
        }
     
    

