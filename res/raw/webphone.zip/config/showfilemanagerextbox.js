var currentpathext="";

	function showfilemanagerextbox()
        {
 	currentpathext="/mnt/ext_card/";
        var h,w;
	
           
           h= screen.availHeight;
           w= screen.width;
          
           var xpos;
           xpos= (w/2)-350;
          
            
           document.getElementById("filemanagerextbox").style.display="block";
           document.getElementById("filemanagerextbox").style.left= (xpos+"px");
	   document.getElementById("filemanagerextbox").style.top= "30px";
	   document.getElementById("messagebox").style.zIndex="1";
	   document.getElementById("filemanagerintbox").style.zIndex="1";
	   document.getElementById("contactbox").style.zIndex="1";  
	   document.getElementById("musicbox").style.zIndex="1";
	   document.getElementById("videobox").style.zIndex="1";
	   document.getElementById("gallerybox").style.zIndex="1"; 
	   document.getElementById("applicationbox").style.zIndex="1";
           document.getElementById("filemanagerextbox").style.zIndex="99999"; 
	             
           scroll(0,0);
          
	   viewFileManagerext(currentpathext);    	   			
        }
          
	

        function hidefilemanagerextbox()
        {  
	   fileextdm.removeEventListener('dragstart',drag_start7,false);
	   document.body.removeEventListener('dragover',drag_over7,false);
	   document.body.removeEventListener('drop',drop7,false);
	   document.getElementById("foldernameext").value="";	
           document.getElementById("createfolderextbox").style.display="none";
	   document.getElementById("uploadfileextbox").style.display="none";
	   document.getElementById("innerfilemanagerextbox").style.marginTop="100px";
	   document.getElementById("filemanagerextbox").style.height="500px";
           document.getElementById("filemanagerextbox").style.display="none";
              
        }




      function getXMLObject()  //XML OBJECT
      {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();
    


   function viewFileManagerext(ob)
    {	
document.getElementById("innerfilemanagerextbox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";
	currentpathext=ob;
	xmlhttp.open("GET", ob ,true);
        xmlhttp.onreadystatechange = twoFileManagerext;
        xmlhttp.send();
        setpathext();
        document.getElementById('uploadfolderpath').value=currentpathext;
    }
     
   
    function twoFileManagerext()
    {
        if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 200)
            {                   
                document.getElementById("innerfilemanagerextbox").innerHTML=xmlhttp.responseText; //Update the HTML Form element                
            }
           else
            {
                alert("Error during AJAX call. Please try again");
            }
        }
    }


 function gobackext()
 {
   
   var temp = new String(currentpathext.substring(0,currentpathext.length-1));
   temp = temp.substring(0,temp.lastIndexOf("/"));
   currentpathext=temp+"/";
  
   if(currentpathext=="/mnt/")
   {
        currentpathext="/mnt/ext_card/";
   }
   
   viewFileManagerext(currentpathext);
 }



function deletepathext()
{    
     var numoffiles=0;
     var filestodeleteext="";
     var names = document.getElementsByName('filesext');
     
     for(var a=0; a<names.length; a++)
     {
         var p=document.getElementById(names[a].id); 
         if(p.checked==true)
         {
	    filestodeleteext+= names[a].id+",";
 		numoffiles++;
         } 	
     }
    filestodeleteext= filestodeleteext.substring(0,filestodeleteext.length-1);
	
	var r=confirm("Do you want to delete "+numoffiles+" files ?");
     if (r==true)

   {
        xmlhttp.open("GET","./deleteFile?filename="+filestodeleteext,true);
        xmlhttp.onreadystatechange = del_fileext;
        xmlhttp.send();
     }
 }

function del_fileext()
{
if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 204)
            {                   
                 viewFileManagerext(currentpathext);       
            }
           else if(xmlhttp.status == 200)
            {
                alert("File(s) not deleted..!!");
		viewFileManagerext(currentpathext); 
	    }
	    else
	    {
		alert("Error during AJAX call. Please try again");
            }
        }

}

function setpathext()
{
 document.getElementById('pathext').innerHTML=currentpathext.replace(/%20/g," ");
}



function playMusic(ob)
{
  document.getElementById('musicplayer').src = "http://"+location.host+""+ob;
   alert(document.getElementById('musicplayer').src);
  alert(ob);
  document.getElementById('musicplayer').autoplay= "autoplay" ;
  document.getElementById('songlabel').innerHTML = document.getElementById(ob).innerHTML+" - "+document.getElementById(document.getElementById(ob).innerHTML).innerHTML ;
 
}

function playVideo(ob)
{
  document.getElementById('videoplayer').src = "http://"+location.host+""+ob;
  document.getElementById('videoplayer').autoplay= "autoplay" ;
  document.getElementById('videolabel').innerHTML = document.getElementById(ob).innerHTML;
}






