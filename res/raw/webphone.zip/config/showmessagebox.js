
        function showmessagebox()
        {
        var h,w;
       
           h= screen.availHeight;
           w= screen.width;
        
           var xpos;
           xpos= (w/2)-350;
          
           
           document.getElementById("messagebox").style.display="block";
           document.getElementById("messagebox").style.left= (xpos+"px");
	   document.getElementById("messagebox").style.top="30px";
	   document.getElementById("videobox").style.zIndex="1";
	   document.getElementById("filemanagerintbox").style.zIndex="1";
	   document.getElementById("contactbox").style.zIndex="1";  
	   document.getElementById("musicbox").style.zIndex="1";
	   document.getElementById("filemanagerextbox").style.zIndex="1";
	   document.getElementById("gallerybox").style.zIndex="1"; 
	   document.getElementById("applicationbox").style.zIndex="1";
           document.getElementById("messagebox").style.zIndex="99999";                
           scroll(0,0);
	
	   viewMessages();	
	
              
        }
      
        function hidemessagebox()
        {  	
		messagedm.removeEventListener('dragstart',drag_start,false);
		document.body.removeEventListener('dragover',drag_over,false);
		document.body.removeEventListener('drop',drop,false);   
 	        document.getElementById("messagename").value="";
	        document.getElementById("messagetext").value="";
	        document.getElementById("sendmessagebox").style.display="none";
                document.getElementById("messagebox").style.display="none";
              
        }



   function getXMLObject()  //XML OBJECT
    {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();
    
        
    function viewMessages()
    {	
        document.getElementById("innermessagebox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";
        xmlhttp.open("GET","./getMessages",true);
        xmlhttp.onreadystatechange = twoMessages;
        xmlhttp.send();
    }
    
    
    function twoMessages()
    {
        if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 200)
            {   
                document.getElementById("innermessagebox").innerHTML=xmlhttp.responseText;//Update the HTML Form element    
            }
          else
            {
                alert("Error during AJAX call. Please try again");
            }
        }
   }


function deleteinbox()
{
	var r3=confirm("Do you want to delete all Inbox Messages.?");
     	if (r3==true)
	{
         document.getElementById("innermessagebox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";
         xmlhttp.open("GET","./deleteMessage",true);
         xmlhttp.onreadystatechange = del_inbox;
         xmlhttp.send();
	}
}

function del_inbox()
{
	if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 204)
            {   
                  viewMessages();
            }
	    else if(xmlhttp.status == 200)
	    {
		alert("Messages not deleted..!!");
		viewMessages();
            }
          else 
            {
                alert("Error during AJAX call. Please try again");
            }
        }
}

     
        
