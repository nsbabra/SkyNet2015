
        function showapplicationbox()
        {
        var h,w;
           
           h= screen.availHeight;
           w= screen.width;
        
           var xpos;
           xpos= (w/2)-350;
          
           
           document.getElementById("applicationbox").style.display="block";
           document.getElementById("applicationbox").style.left= (xpos+"px");
	   document.getElementById("applicationbox").style.top="30px";
	   document.getElementById("messagebox").style.zIndex="1";
	   document.getElementById("filemanagerintbox").style.zIndex="1";
	   document.getElementById("contactbox").style.zIndex="1";  
	   document.getElementById("musicbox").style.zIndex="1";
	   document.getElementById("filemanagerextbox").style.zIndex="1";
	   document.getElementById("gallerybox").style.zIndex="1"; 
	   document.getElementById("videobox").style.zIndex="1";
           document.getElementById("applicationbox").style.zIndex="99999";                
           scroll(0,0);
	   
	   viewApps();	

              
        }
      
        function hideapplicationbox()
        { 
	   applicationdm.removeEventListener('dragstart',drag_start2,false);
	   document.body.removeEventListener('dragover',drag_over2,false);
	   document.body.removeEventListener('drop',drop2,false); 
           document.getElementById("applicationbox").style.display="none";
              
        }


   function getXMLObject()  //XML OBJECT
    {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();

    
        
    function viewApps()
    {
	document.getElementById("innerapplicationbox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";
        xmlhttp.open("GET","./getApps",true);
        xmlhttp.onreadystatechange = twoApplications;
        xmlhttp.send();
    }
    
    
    function twoApplications()
    {
        if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 200)
            {   
                
                document.getElementById("innerapplicationbox").innerHTML=xmlhttp.responseText;//Update the HTML Form element               
            }
            else
            {
                alert("Error during AJAX call..!!");
            }
        }
   }
     


function uninstallApp(packagename)
{	
	xmlhttp.open("GET","./uninstallApp?name="+packagename,true);
        xmlhttp.onreadystatechange = unins_app;
        xmlhttp.send();
}
        
function unins_app()
{
   if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 204)
            {   
                alert("Please finish uninstallation on your device..!!");
            }
	    else
            {}
        }
}
