
        function showcontactbox()
        {
        var h,w;
           
           h= screen.availHeight;
           w= screen.width;
        
           var xpos;
           xpos= (w/2)-350;
          
           
           document.getElementById("contactbox").style.display="block";
           document.getElementById("contactbox").style.left= (xpos+"px");
	   document.getElementById("contactbox").style.top="30px";
	   document.getElementById("messagebox").style.zIndex="1";
	   document.getElementById("filemanagerintbox").style.zIndex="1";
	   document.getElementById("videobox").style.zIndex="1";  
	   document.getElementById("musicbox").style.zIndex="1";
	   document.getElementById("filemanagerextbox").style.zIndex="1";
	   document.getElementById("gallerybox").style.zIndex="1"; 
	   document.getElementById("applicationbox").style.zIndex="1";
	   document.getElementById("contactbox").style.zIndex="99999";                   
           scroll(0,0);
	   
	  viewContacts();

              
        }
      
        function hidecontactbox()
        {      
		contactdm.removeEventListener('dragstart',drag_start1,false);
		document.body.removeEventListener('dragover',drag_over1,false);
		document.body.removeEventListener('drop',drop1,false); 
	    document.getElementById("contactname").value="";
	    document.getElementById("contactnumber").value="";
	    document.getElementById("createcontactbox").style.display="none";
	    document.getElementById("innercontactbox").style.marginTop="100px";
	    document.getElementById("contactbox").style.height="500px";
            document.getElementById("contactbox").style.display="none";
              
        }



   function getXMLObject()  //XML OBJECT
    {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();
    
        
    function viewContacts()
    {
	document.getElementById("innercontactbox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";
        xmlhttp.open("GET","./getContacts",true);
        xmlhttp.onreadystatechange = twoContacts;
        xmlhttp.send();
    }
    
    
    function twoContacts()
    {
        if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 200)
            {   
                
                document.getElementById("innercontactbox").innerHTML=xmlhttp.responseText;   //Update the HTML Form element    
            }            
            else
            {
                alert("Error during AJAX call. Please try again");
            }
        }
    }
     
    



 function deleteContactnames()
 {
    var numberofcontacts=0; 
    var contactstodel="";
   
     var cnames = document.getElementsByName('contacts');
  
     for(var a=0; a<cnames.length; a++)
     {
         var p=document.getElementById(cnames[a].id); 
         if(p.checked==true)
         {
	    contactstodel+= cnames[a].id+",";
	    numberofcontacts++;
         } 	
     }
     contactstodel= contactstodel.substring(0,contactstodel.length-1);
     var r=confirm("Do you want to delete "+numberofcontacts+" contacts ?");
     if (r==true)
     {
       xmlhttp.open("GET","./deleteContact?name="+contactstodel,true);
       xmlhttp.onreadystatechange =  del_contactresponse; 
       xmlhttp.send();  
     }
 }



function del_contactresponse()
{
	if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 204)
            {   
  		 viewContacts();
            }            
            else if(xmlhttp.status == 200)
            {
                alert("Contacts not deleted");
		viewContacts();
            }
            else
	    {
		alert("Error during AJAX call");
	    }
        }	

}








