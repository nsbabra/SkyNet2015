
        function showuploadfileintbox()
        { 
        var h,w;
           
           h= screen.availHeight;
           w= screen.width;
        
           var xpos;
           xpos= (w/2)-480;
          
           document.getElementById("createfolderintbox").style.display="none";
           document.getElementById("uploadfileintbox").style.display="block";
           document.getElementById("uploadfileintbox").style.left= (xpos+"px");
	   document.getElementById("innerfilemanagerintbox").style.marginTop="200px";
	   document.getElementById("filemanagerintbox").style.height="600px";
	   document.getElementById("uploadfileintbox").style.zIndex="3";                   
           scroll(0,0);
	   
	   document.getElementById('uploadfolderipint').value=location.hostname;

              
        }

	
      
        function closeuploadfileintbox()
        {	
	  //document.getElementById("foldernameext").value="";
          document.getElementById("uploadfileintbox").style.display="none";
	  document.getElementById("innerfilemanagerintbox").style.marginTop="100px";
	  document.getElementById("filemanagerintbox").style.height="500px";
              
        }

    

     
    

