function getXMLObject()  //XML OBJECT
    {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();
    

function saveOnDevice()
{
        var cliptext = document.getElementById('clipboardtext').value.replace(/\n/g,"%0D%0A");
        xmlhttp.open("GET", "./setClipboard?text="+cliptext ,true);
	xmlhttp.onreadystatechange = savetoclip;
        xmlhttp.send();
}

function savetoclip()
{

}


function refreshondevice()
{
	xmlhttp.open("GET", "./getClipboard",true);
	xmlhttp.onreadystatechange = twoClipboard;
        xmlhttp.send();
}


 function twoClipboard()
    {
        if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 200)
            {   
                
                document.getElementById('clipboardtext').value=xmlhttp.responseText;   //Update the HTML Form element
                
             }
          
            else
            {
                alert("Error during AJAX call. Please try again");
            }
        }
    }
