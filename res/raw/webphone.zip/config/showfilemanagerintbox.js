var currentpathint="";

	function showfilemanagerintbox()
        {
 	currentpathint="/mnt/sdcard/";
        var h,w;
	
           
           h= screen.availHeight;
           w= screen.width;
          
           var xpos;
           xpos= (w/2)-350;
          
           
           document.getElementById("filemanagerintbox").style.display="block";
           document.getElementById("filemanagerintbox").style.left= (xpos+"px");
	   document.getElementById("filemanagerintbox").style.top = "30px";
	   document.getElementById("messagebox").style.zIndex="1";
	   document.getElementById("videobox").style.zIndex="1";
	   document.getElementById("contactbox").style.zIndex="1";  
	   document.getElementById("musicbox").style.zIndex="1";
	   document.getElementById("filemanagerextbox").style.zIndex="1";
	   document.getElementById("gallerybox").style.zIndex="1"; 
	   document.getElementById("applicationbox").style.zIndex="1";
           document.getElementById("filemanagerintbox").style.zIndex="99999";                
           scroll(0,0);
          
	   viewFileManagerint(currentpathint);
    	   			
        }
          
 

	 function hidefilemanagerintbox()
        {  
	   fileintdm.removeEventListener('dragstart',drag_start6,false);
	   document.body.removeEventListener('dragover',drag_over6,false);
	   document.body.removeEventListener('drop',drop6,false); 
	   document.getElementById("foldernameint").value="";	
           document.getElementById("createfolderintbox").style.display="none";
	   document.getElementById("uploadfileintbox").style.display="none";
	   document.getElementById("innerfilemanagerintbox").style.marginTop="100px";
	   document.getElementById("filemanagerintbox").style.height="500px";
           document.getElementById("filemanagerintbox").style.display="none";              
        }


      function getXMLObject()  //XML OBJECT
      {
       var xmlHttp = false;
        try
        {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP")  // For Old Microsoft Browsers
        }
        catch (e)
        {
            try
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")  // For Microsoft IE 6.0+
            }
            catch (e2)
            {
                xmlHttp = false   // No Browser accepts the XMLHTTP Object then false
            }
        }
        if (!xmlHttp && typeof XMLHttpRequest != 'undefined')
        {
            xmlHttp = new XMLHttpRequest();        //For Mozilla, Opera Browsers
        }
        return xmlHttp;  // Mandatory Statement returning the ajax object created
    }
    var xmlhttp = new getXMLObject();
    


   function viewFileManagerint(ob)
    {
	document.getElementById("innerfilemanagerintbox").innerHTML = "<img src=\"../.images/loading1.gif\" id=\"loading\" width=\"50\" height=\"50\"/><div style=\"clear:both;\"></div>";
	currentpathint=ob;
	xmlhttp.open("GET", ob ,true);
        xmlhttp.onreadystatechange = twoFileManagerint;
        xmlhttp.send();
	setpathint();
	document.getElementById('uploadfolderpathint').value=currentpathint;
	//alert(document.getElementById('uploadfolderpathint').value);
    }
   function setpathint()  
   {
     document.getElementById('pathint').innerHTML=currentpathint.replace(/%20/g," ");
   }
     
   
    function twoFileManagerint()
    {
        if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 200)
            {                   
                document.getElementById("innerfilemanagerintbox").innerHTML=xmlhttp.responseText; //Update the HTML Form element                
            }
           else
            {
                alert("Error during AJAX call. Please try again");
            }
        }
    }


function deletepathint()
{    
     var numoffilesint=0;
     var filestodeleteint="";
     var names = document.getElementsByName('filesint');
     	
     for(var a=0; a<names.length; a++)
     {
         var p=document.getElementById(names[a].id); 
         if(p.checked==true)
         {
	    filestodeleteint+= names[a].id+",";
	    numoffilesint++;
         } 	
     }
    filestodeleteint= filestodeleteint.substring(0,filestodeleteint.length-1);
	
   var r2=confirm("Do you want to delete "+numoffilesint+" files ?");
     if (r2==true)

   {
       xmlhttp.open("GET","./deleteFile?filename="+filestodeleteint,true);
      
        xmlhttp.onreadystatechange = del_fileint;
        xmlhttp.send();
    }   
 }

function del_fileint()
{
	if (xmlhttp.readyState == 4)
        {
            if(xmlhttp.status == 204)
            {                   
                 viewFileManagerint(currentpathint);       
            }
           else if(xmlhttp.status == 200)
            {
                alert("File(s) not deleted..!!");
		viewFileManagerint(currentpathint); 
	    }
	    else
	    {
		alert("Error during AJAX call. Please try again");
            }
        }
}







 function gobackint()
 {
  
   var temp = new String(currentpathint.substring(0,currentpathint.length-1));
   temp = temp.substring(0,temp.lastIndexOf("/"));
   currentpathint=temp+"/";
   if(currentpathint=="/mnt/")
   {
        currentpathint="/mnt/sdcard/";
   }
  viewFileManagerint(currentpathint);
 }








 function setpathint()
{
document.getElementById('pathint').innerHTML=currentpathint.replace(/%20/g," ");
}

